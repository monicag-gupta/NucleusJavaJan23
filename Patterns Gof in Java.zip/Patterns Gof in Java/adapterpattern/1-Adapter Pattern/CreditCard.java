

// this is the target interface.

public interface CreditCard 

{
	public void giveBankDetails();
	public String getCreditCard();
	
}
