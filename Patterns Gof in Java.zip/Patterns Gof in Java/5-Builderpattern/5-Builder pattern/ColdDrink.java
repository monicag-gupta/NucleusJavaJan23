/**
 *
 * @author Ashwani
 */
public abstract  class ColdDrink implements Item{

   
    
    @Override
    public abstract float price();
    
}
